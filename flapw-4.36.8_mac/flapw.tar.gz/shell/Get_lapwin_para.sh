#! /bin/sh

#set for variables ---------------------
workdir='work'
jobfile='job_ito_mpi.sh'
lapwin='lapwin_para'
cha='sedval'; val='3.0 3.1 3.2'; name='para'
#end for variables ---------------------

#working directory
fdir=$PWD
jobsh=$workdir'.sh'

#check job.sh
if [ ! -f $fdir/$jobfile ] ; then
  echo "no job.sh at $fdir" ; exit
fi

#check lapwin
if [ ! -f $fdir/$lapwin ] ; then
  echo "no lapwin at $fdir" ; exit
fi

#check sh_edit
if [ ! -f $fdir/sh_edit ] ; then
  echo "no sh_edit at $fdir" ; exit
fi

#make working directory
if [ ! -d $workdir ] ; then
  mkdir $workdir
fi
cd $workdir

#gen job.sh
echo '#!/bin/bash' >  $jobsh
echo -n "dir='"    >> $jobsh

#loop for variables
for i in $val ; do

  #get directry
  dir=$name$i
  echo -n "$dir " >> $jobsh

  #make directory
  if [ ! -d $dir ] ; then
    mkdir $dir
  fi
  cd $dir
  echo "$dir"

  #copy $dir.sh
  if [ -f $fdir/$jobfile ] ; then
    cp -f $fdir/$jobfile $dir'.sh'
    chmod 744 $dir'.sh'
  fi

  #copy lapwin
  if [ -f $fdir/$lapwin ] ; then
    cp -f $fdir/$lapwin lapwin
  fi

  #sed $cha to $i
  sed -i -e "s/$cha/$i/g" lapwin
  
cd ..
done
#end loop for variables

echo "'"                   >> $jobsh
echo ''                    >> $jobsh

#copy shell
cat $fdir/sh_edit >> $jobsh
chmod 744 $jobsh

#back pwd
cd $fdir
