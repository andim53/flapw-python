#!/bin/bash

#PJM -L "rscunit=ito-a"
#---9 core
#PJM -L "rscgrp=ito-q"
#PJM -L "vnode=1"
#PJM -L "vnode-core=9"
#PJM -L "elapse=168:00:00"
#---1 core
##PJM -L "rscgrp=ito-single"
##PJM -L "vnode=1"
##PJM -L "vnode-core=1"
##PJM -L "elapse=168:00:00"
#---36 core
##PJM -L "rscgrp=ito-ss"
##PJM -L "vnode=1"
##PJM -L "vnode-core=36"
##PJM -L "elapse=96:00:00"
#---debug 
##PJM -L "rscgrp=ito-q-dbg"
##PJM -L "vnode=1"
##PJM -L "vnode-core=9"
##PJM -L "elapse=1:00:00"
#---
#PJM -o log
#PJM -j
#PJM -X

rm *.sh.o*
XRUN=./pflapw
#XRUN2=./xanis

NUM_NODES=${PJM_VNODES}
NUM_CORES=9
NUM_PROCS=9

export I_MPI_PERHOST=$NUM_CORES
#export I_MPI_FABRICS=shm:ofa
export I_MPI_FABRICS=shm:ofi

export I_MPI_HYDRA_BOOTSTRAP=rsh
export I_MPI_HYDRA_BOOTSTRAP_EXEC=/bin/pjrsh
export I_MPI_HYDRA_HOST_FILE=${PJM_O_NODEINF}
export I_MPI_SHM_HEAP_VSIZE=43008
#export I_MPI_DEBUG=10

mpiexec.hydra -n $NUM_PROCS $XRUN
#mpiexec.hydra -n $NUM_PROCS $XRUN2
