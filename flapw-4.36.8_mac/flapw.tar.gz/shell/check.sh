#!/bin/bash

#dir1 begin
pwd1=`pwd`
dir1="*"
#dir1="ZZ*"
count1=0
for i1  in $dir1  ; do
if [ -d $i1 ] ; then
if [ ${i1:0:3} != 'src' ] ; then
if [ ${i1:0:4} != 'back' ] ; then
if [ $i1 != 'done' ] ; then
cd $i1
count1=$((count1+1))

#dir2 begin
pwd2=`pwd`
dir2="*"
#dir2="XX*"
count2=0
for i2 in $dir2 ; do
if [ -d $i2 ] ; then
if [ ${i2:0:3} != 'src' ] ; then
if [ ${i2:0:4} != 'back' ] ; then
if [ $i2 != 'done' ] ; then
cd $i2
count2=$((count2+1))

#subdir begin
  subpwd=`pwd`
  #subdir="*"
  subdir='slf*'
  count3=0
  for j in $subdir ; do
  if [ -d $j ] ; then
  if [ ${j:0:3} != 'src' ] ; then
  if [ ${j:0:4} != 'back' ] ; then
  if [ $j != 'done' ] ; then
  count3=$((count3+1))

#adddir begin
# orgname='slf'
# newname='dos'
# adddir=`echo $j | sed "s/$orgname/$newname/g"`
# --copy--
# echo 'cp '$j' '$adddir
# cp -fr $j $adddir
# --rename--
# echo 'mv '$j' '$adddir
# mv $j $adddir
#end adddir

  cd $j

    echo ''
    echo $i1'  '$i2'  '$j
    #echo -n '  '$count3'   '$i1'   '$i2'   '$j'   '

    fname=''
    #fname='K16'

    #cp ~/FLAPW/src/job.sh $j'.sh'
    #cp ~/FLAPW/src/pflapw .
    #cp ~/FLAPW/src/postCAL/postDOS/xdos .
    #cp ~/FLAPW/src/postCAL/postDOS/dosin .

    #cp lapwin$fname lapwin
    #vi lapwin
    #diff lapwin ../org/lapwin

    #FLcopy $fname
    #FLclean
    #FLrst $fname
    #pjsub $i2.sh

    #FLchk $fname | grep ' itf= ' | tail -1
    #FLchk $fname | grep distance | grep charge | tail -1
    #FLchk $fname | grep distance | grep spin   | tail -1
    #FLchk $fname | grep 'Warning'
    #FLchk $fname | grep 'FLAPW calculations were done'
    #grep 'set charge convergency' lapwout$fname | tail -1
    #grep 'FLAPW VERSION' lapwout$fname

    #echo -n $j'  '
    #grep 'total energy' lapwout$fname | awk '{print $6}' | tail -1
    #grep 'fermi energy' lapwout$fname |  awk '{print $4}' | tail -1
    #if [ -f anisout$fname ] ; then
    #  grep 'Fermi energy' anisout$fname
    #  grep MCA anisout$fname | grep V  | grep '90.00   0.0' | awk '{print $9}'
    #  grep MCA anisout$fname | awk '{print $3 "   "  $9}' > mca$fname'.xy'
    #fi

#sh_edit begin
#copy sh_edit and edit for lapwin
#
#sh_edif end

  cd $subpwd
  fi
  fi
  fi
  fi
  done
#subdir end

cd $pwd2
fi
fi
fi
fi
done
#dir2 end

cd $pwd1
fi
fi
fi
fi
done
#dir1 end
