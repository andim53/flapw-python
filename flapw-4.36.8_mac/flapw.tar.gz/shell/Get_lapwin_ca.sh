#! /bin/sh
#need Get_lapwin_para.sh

#set for variables ---------------------
lapwin='lapwin_ca'
cha='caval'; val='1.00 1.02 1.04 1.06 1.08'; name='ca'
#end for variables ---------------------

#check lapwin
if [ ! -f $lapwin ] ; then
  echo "no $lapwin" ; exit
fi

#loop for variables
for i in $val ; do

  #sed $cha to $i
  cp $lapwin lapwin_para
  sed -i -e "s/$cha/$i/g" lapwin_para
  ./Get_lapwin_para.sh
  rm lapwin_para
  mv work $name$i
  
done
