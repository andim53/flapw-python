#!/bin/sh

#SBATCH -p F4cpu  #partision 24h
#SBATCH -N 4       #node
#SBATCH -n 16      #mpi
#SBATCH -t 24:00:00    #time

##SBATCH -p L4cpu  #partision 120h
##SBATCH -N 4       #node
##SBATCH -n 16      #mpi
##SBATCH -t 120:00:00    #time

##SBATCH -p F1cpu  #partision 24h
##SBATCH -N 1       #node
##SBATCH -n 16      #mpi
##SBATCH -t 24:00:00    #time

##Ohters
##SBATCH -p L1cpu  #partision 120h
##SBATCH -p B1cpu  #partision 12h
##SBATCH -p i8cpu  #partision debag

##Serial 
##SBATCH -p i8cpu  #partision
##SBATCH -N 1      #node
##SBATCH -n 1      #parallel
##SBATCH -c 1

##Batch comand
##sbatch
##squeue
##scancel jobid
##pstat

ulimit -s unlimited
srun ./pflapw
