#!/bin/sh

#PJM -L rscgrp=a-pj24001864
##PJM -L rscgrp=a-batch
#PJM -L vnode-core=16
#PJM --mpi proc=16
#PJM -L elapse=72:00:00
#PJM -j
#PJM -X

module load intel
module load impi

##Batch
##pjsub
##pjstat
##pjdel
##pjshowrsc --rg

##.bashrc
##module load intel
##module load impi
##PATH="$HOME/bin:$HOME/FLAPW/bin:$PATH"

mpiexec ./pflapw
