#!/bin/sh

if  [ $# = 0 ]
    then np=1
else
    np=$1
fi

if [ ! -f mpifile ]
  then echo "copy mpifile for MPI"
       exit
fi

mpiexec -f mpifile -n $np ./pflapw
#mpiexec -f mpifile -n $np ./pflapw >& log &

#mpifile---
#localhost
#ncm30:1
#ncm31:1
#ncm32:1
#-------------

#bacground job---
#mpiexec -f mpifile -n 2 ./pflapw >& log &
