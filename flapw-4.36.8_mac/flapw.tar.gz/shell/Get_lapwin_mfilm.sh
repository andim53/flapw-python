#! /bin/sh

#set for variables: edit----------------
jobfile='job_ito_mpi.sh'
workdir='work_mfilm'
lapwin='lapwin_mfilm'
sedname='sed'
#9ML
d0=(C F); atom0=(Co Fe); zdel0=(2.10 2.44); mmnt0=(2.0 3.0)
d1=(C F); atom1=(Co Fe); zdel1=(2.60 2.67); mmnt1=(2.0 3.0)
d2=(C F); atom2=(Co Fe); zdel2=(2.35 2.61); mmnt2=(2.0 3.0)
d3=(C F); atom3=(Co Fe); zdel3=(2.35 2.61); mmnt3=(2.0 3.0)
d4=(C F); atom4=(Co Fe); zdel4=(2.35 2.61); mmnt4=(2.0 3.0)
d5=(C F); atom5=(Co Fe); zdel5=(2.35 2.61); mmnt5=(2.0 3.0)
d6=(C F); atom6=(Co Fe); zdel6=(2.63 2.67); mmnt6=(2.0 3.0)
d7=(C F); atom7=(Co Fe); zdel7=(2.20 2.37); mmnt7=(2.0 3.0)
d8=(C F); atom8=(Co Fe); zdel8=(4.00 3.97); mmnt8=(2.0 3.0)
#end for variables ---------------------

#setting for slab
sedzslab=`echo "scale=2; 12.13+${zdel0[1]}+${zdel1[1]}+${zdel2[1]}+${zdel3[1]}+${zdel4[1]}+${zdel5[1]}+${zdel6[1]}+${zdel7[1]}+${zdel8[1]}" | bc`
sedzref=`echo "scale=2; ($sedzslab+2.2+2.0+1.0)/2.0-2.2-0.5-$sedzslab+12.13" | bc `

#working directory
fdir=$PWD
jobsh=$workdir'.sh'

#check job.sh
if [ ! -f $fdir/$jobfile ] ; then
  echo "no job.sh at $fdir" ; exit
fi

#check lapwin
if [ ! -f $fdir/$lapwin ] ; then
  echo "no lapwin at $fdir" ; exit
fi

#check sh_edit
if [ ! -f $fdir/sh_edit ] ; then
  echo "no sh_edit at $fdir" ; exit
fi

#make working directory
if [ ! -d $workdir ] ; then
  mkdir $workdir
fi
cd $workdir

#creat job.sh
echo '#!/bin/bash' >  $jobsh
echo -n "dir='"    >> $jobsh

#loop for variables: edit-----------------
for((i0=0; i0 < ${#d0[@]}; i0++)); do 
for((i1=0; i1 < ${#d1[@]}; i1++)); do 
for((i2=0; i2 < ${#d2[@]}; i2++)); do 
for((i3=0; i3 < ${#d3[@]}; i3++)); do 
for((i4=0; i4 < ${#d4[@]}; i4++)); do 
for((i5=0; i5 < ${#d5[@]}; i5++)); do 
for((i6=0; i6 < ${#d6[@]}; i6++)); do 
for((i7=0; i7 < ${#d7[@]}; i7++)); do 
for((i8=0; i8 < ${#d8[@]}; i8++)); do 
#8ML loop
  cdir=`pwd`

  #get direictory
  dir=${d0[$i0]}${d1[$i1]}${d2[$i2]}${d3[$i3]}${d4[$i4]}${d5[$i5]}${d6[$i6]}${d7[$i7]}${d8[$i8]}
  echo -n "$dir " >> $jobsh

  #cd directory
  if [ ! -d $dir ] ; then
    mkdir $dir
  fi
  cd $dir

  #copy $dir.sh
  cp -f $fdir/$jobfile $dir'.sh'
  chmod 744 $dir'.sh'

  #copy lapwin
  cp -f $fdir/$lapwin lapwin

  #sedslab
  sed -i -e "s/sedzslab/$sedzslab/g" lapwin
  if [ `echo "$sedzref < 0.00" | bc` -eq 1 ] ; then
    sed -i -e "s/+sedzref/$sedzref/" lapwin
  else
    sed -i -e "s/sedzref/$sedzref/" lapwin
  fi
  
  #sedatom
  sed -i -e "s/${sedname}atom0/${atom0[$i0]}/" lapwin
  sed -i -e "s/${sedname}atom1/${atom1[$i1]}/" lapwin
  sed -i -e "s/${sedname}atom2/${atom2[$i2]}/" lapwin
  sed -i -e "s/${sedname}atom3/${atom3[$i3]}/" lapwin
  sed -i -e "s/${sedname}atom4/${atom4[$i4]}/" lapwin
  sed -i -e "s/${sedname}atom5/${atom5[$i5]}/" lapwin
  sed -i -e "s/${sedname}atom6/${atom6[$i6]}/" lapwin
  sed -i -e "s/${sedname}atom7/${atom7[$i7]}/" lapwin
  sed -i -e "s/${sedname}atom8/${atom8[$i8]}/" lapwin
  #sedzdel
  z8=${zdel8[$i8]}
  z7=`echo "scale=3; ${zdel7[$i7]}+$z8" | bc`
  z6=`echo "scale=3; ${zdel6[$i6]}+$z7" | bc`
  z5=`echo "scale=3; ${zdel5[$i5]}+$z6" | bc`
  z4=`echo "scale=3; ${zdel4[$i4]}+$z5" | bc`
  z3=`echo "scale=3; ${zdel3[$i3]}+$z4" | bc`
  z2=`echo "scale=3; ${zdel2[$i2]}+$z3" | bc`
  z1=`echo "scale=3; ${zdel1[$i1]}+$z2" | bc`
  z0=`echo "scale=3; ${zdel0[$i0]}+$z1" | bc`
  sed -i -e "s/${sedname}zdel0/$z0/" lapwin
  sed -i -e "s/${sedname}zdel1/$z1/" lapwin
  sed -i -e "s/${sedname}zdel2/$z2/" lapwin
  sed -i -e "s/${sedname}zdel3/$z3/" lapwin
  sed -i -e "s/${sedname}zdel4/$z4/" lapwin
  sed -i -e "s/${sedname}zdel5/$z5/" lapwin
  sed -i -e "s/${sedname}zdel6/$z6/" lapwin
  sed -i -e "s/${sedname}zdel7/$z7/" lapwin
  sed -i -e "s/${sedname}zdel8/$z8/" lapwin
  #sedmmnt
  sed -i -e "s/${sedname}mmnt0/${mmnt0[$i0]}/" lapwin
  sed -i -e "s/${sedname}mmnt1/${mmnt1[$i1]}/" lapwin
  sed -i -e "s/${sedname}mmnt2/${mmnt2[$i2]}/" lapwin
  sed -i -e "s/${sedname}mmnt3/${mmnt3[$i3]}/" lapwin
  sed -i -e "s/${sedname}mmnt4/${mmnt4[$i4]}/" lapwin
  sed -i -e "s/${sedname}mmnt5/${mmnt5[$i5]}/" lapwin
  sed -i -e "s/${sedname}mmnt6/${mmnt6[$i6]}/" lapwin
  sed -i -e "s/${sedname}mmnt7/${mmnt7[$i7]}/" lapwin
  sed -i -e "s/${sedname}mmnt8/${mmnt8[$i8]}/" lapwin

  cd $cdir
#8ML loop
done
done
done
done
done
done
done
done
done
#loop for variables-----------------------

#close directories
echo "'"                   >> $jobsh
echo ''                    >> $jobsh

#copy shell
cat $fdir/sh_edit >> $jobsh
chmod 744 $jobsh

#back pwd
cd $fdir
