#!/bin/bash
#PJM -L "rscunit=ito-a"
#PJM -L "rscgrp=ito-q"
##PJM -L "rscgrp=ito-q-dbg"
#PJM -L "vnode=1"
#PJM -L "vnode-core=9"
#PJM -L "elapse=168:00:00"
#PJM -j
#PJM -X

NUM_NODES=${PJM_VNODES}
NUM_CORES=9
NUM_PROCS=9
export I_MPI_PERHOST=$NUM_CORES
export I_MPI_FABRICS=shm:ofa
export I_MPI_HYDRA_BOOTSTRAP=rsh
export I_MPI_HYDRA_BOOTSTRAP_EXEC=/bin/pjrsh
export I_MPI_HYDRA_HOST_FILE=${PJM_O_NODEINF}

rm *.sh.o*
#XRUN2=./xoptics
#mpiexec.hydra -n $NUM_PROCS $XRUN2

shopt -s expand_aliases
xrun='xoptics'

#begin_set --------------------------------
x1=-0.1
x2=0.1
num=4
sedvalue='sedvalue'
filein='SEDopticsin'
fileout='opticsout'
dirout='SED'

cal='yes'
#cal='no'

#alias opt="grep -h -A9 PLASMA    | grep -A3 up+dw | grep -v up+dw | grep x | awk '{print \$2}'"
#alias opt="grep -h -A9 PLASMA    | grep -A3 up-dw | grep -v up-dw | grep x | awk '{print \$2}'"
alias opt="grep -h -A9 INTERBAND | grep -A3 up+dw | grep -v up+dw | grep y | awk '{print \$2}'"
#alias opt="grep -h -A9 INTERBAND | grep -A3 up-dw | grep -v up-dw | grep y | awk '{print \$2}'"
#end_set -------------------------------------

#-----------------------------
if [ $cal = 'yes' ] ; then
  if [ ! -f $filein ] ; then
    echo "no file $filein"
    exit
  fi
  if [ ! -f $xrun ] ; then
    echo "no file $filein"
    exit
  fi
fi

if [ -f $dirout/SED$fileout ] ; then
  mv $dirout/SED$fileout $dirout/SED$fileout'.old'
fi
mkdir -p $dirout

del=`echo "scale=4; ($x2 - $x1) / ($num-1)" | bc`
for ((i=0; i < $num; i++)); do
  val=`echo "scale=4; $x1 + $i * $del" | bc`
  if [ $cal = 'yes' ] ; then
    cat $filein | sed -e "s/$sedvalue/$val/g" > ./opticsin
#   ./$xrun
    mpiexec.hydra -n $NUM_PROCS ./$xrun
    cp opticsin $dirout/opticsin$i
    cp $fileout $dirout/$fileout$i
  fi
  x=`printf "%0.4f\n" $val`
  y=`cat $dirout/$fileout$i | opt`
  echo $i $'  ' $x $'  ' $y >> $dirout/SED$fileout
done
