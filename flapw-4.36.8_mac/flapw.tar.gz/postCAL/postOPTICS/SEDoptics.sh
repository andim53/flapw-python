#!/bin/sh
#

#begin_set
x1=-1.0
x2=1.0
num=21
sedvalue='sedvalue'
filein='SEDopticsin'
fileout='opticsout'
dirout='SED'
cal='yes'
#cal='no'
xrun='xoptics'
 alias opt="grep -h -A9 PLASMA    | grep -A3 up+dw | grep -v up+dw | grep x | awk '{print \$2}'"
#alias opt="grep -h -A9 PLASMA    | grep -A3 up-dw | grep -v up-dw | grep x | awk '{print \$2}'"
#alias opt="grep -h -A9 INTERBAND | grep -A3 up+dw | grep -v up+dw | grep y | awk '{print \$2}'"
#alias opt="grep -h -A9 INTERBAND | grep -A3 up-dw | grep -v up-dw | grep y | awk '{print \$2}'"
#end_set

#-----------------------------
if [ $cal = 'yes' ] ; then
  if [ ! -f $filein ] ; then
    echo "no file $filein"
    exit
  fi
  if [ ! -f $xrun ] ; then
    echo "no file $filein"
    exit
  fi
fi

if [ -f $dirout/SED$fileout ] ; then
  mv $dirout/SED$fileout $dirout/SED$fileout'.old'
fi
mkdir -p $dirout

del=`echo "scale=4; ($x2 - $x1) / ($num-1)" | bc`
for ((i=0; i < $num; i++)); do
  val=`echo "scale=4; $x1 + $i * $del" | bc`
  if [ $cal = 'yes' ] ; then
    cat $filein | sed -e "s/$sedvalue/$val/g" > ./opticsin
    ./$xrun
    cp opticsin $dirout/opticsin$i
    cp $fileout $dirout/$fileout$i
  fi
  x=`printf "%0.4f\n" $val`
  y=`cat $dirout/$fileout$i | opt`
  echo $i $'  ' $x $'  ' $y >> $dirout/SED$fileout
done
